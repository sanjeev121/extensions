#Description

Save time in lead generation & business development with the Leonard automation bot.

#Terms & Conditions


The following terms and conditions govern all use of the MeetLeonard.com website and all content, services and products available at, or through, the website, including, but not limited to, the Meet Leonard web browser extension/s and software (“Leonard”), (taken together, the Services). 
The Services offered is subject to your acceptance without modification of all of the terms and conditions contained herein and all other operating rules, policies, and procedures that may be published from time to time on this Site by MeetLeonard.com (collectively, the “Agreement”), and they apply to all visitors, users and others who access or use the Service.
Please read this Agreement carefully before accessing or using the Services. By accessing or using any part of the website, you agree to become bound by the terms and conditions of this agreement. If you do not agree to all the terms and conditions of this agreement, then you may not access or use the Services. If these terms and conditions are considered an offer by Leonard, acceptance is expressly limited to these terms. The Services are available only to individuals who are at least 18 years old.

#Requirements:

Browser : Mozilla Firefox version > 50
OS : Any(that supports Mozilla Browser)


#Installation & Run

1.Install the Addon through mozilla store.
2.Login to Linked-in account and load your extension.
3.Migrate through various options in the pop-up page.

Note : The extension has some of the features that are paid.
